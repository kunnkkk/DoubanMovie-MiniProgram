// miniprogram/pages/movie/movie.js
Page({

  data: {
    movieList: [] ,//正在热映
    topList:[],//top250
  },

  getInfo: function () {
    wx.showLoading({  //显示加载页面
      title: '加载中...',
    })
    //正在热映
    wx.cloud.callFunction({
      name: 'movies',
      data: {
        start: this.data.movieList.length,
        count: 40
      }
    }).then(res => { //res里面存储大量信息
      console.log(res)
      this.setData({
        movieList: this.data.movieList.concat(JSON.parse(res.result).subjects)
      })
      wx.hideLoading() //结束加载页面
    }).catch(err => {
      console.log(err)
      wx.hideLoading()
    })
    //top250
    wx.cloud.callFunction({
      name: 'top',
      data: {
        start: this.data.topList.length,
        count: 10
      }
    }).then(res => { //res里面存储大量信息
      console.log(res)
      this.setData({
        topList: this.data.topList.concat(JSON.parse(res.result).subjects)
      })
      wx.hideLoading() //结束加载页面
    }).catch(err => {
      console.log(err)
      wx.hideLoading()
    })
  },

  gotoDetail: function (event) {
    console.log(event.target.dataset.movieid) //通过event获取自定义属性movieid
    wx.navigateTo({ //该方法跳转到其他页面，保留本身页面
      url: `../detail/detail?movieid=${event.target.dataset.movieid}`,
    })
  },

  gotoComment: function (event) {
    console.log(event.target.dataset.movieid) //通过event获取自定义属性movieid
    wx.navigateTo({ //该方法跳转到其他页面，保留本身页面
      url: `../comment/comment?movieid=${event.target.dataset.movieid}`,
    })
  },


  onLoad:function(options){
      this.getInfo()
  },


  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})