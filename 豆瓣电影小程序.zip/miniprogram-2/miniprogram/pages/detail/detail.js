// miniprogram/pages/detail/detail.js
const db = wx.cloud.database();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    datail: {}, //详情页面对象
    comment: {}, //评论
    _wantedId:'',
    _watchedId: ''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    console.log(options) //可以打印出我们传过来的movieid
    wx.cloud.callFunction({
        name: "gotoDetail",
        data: { //同时需要传过来的movieid参数
          movieid: options.movieid
        }
      }).then(res => {
        console.log(res)
        //如果成功，我们将拿到的数据赋值给我们定义在data中的detail对象赋值
        this.setData({
          detail: JSON.parse(res.result)
          //拿到detail对象后我们就可以通过它显示数据在我们页面上了
        })
      }).catch(err => {
        console.log(err)
      }),
      wx.cloud.callFunction({
        name: "userComment",
        data: { //同时需要传过来的movieid参数
          movieid: options.movieid
        }
      }).then(res => {
        console.log(res)
        //如果成功，我们将拿到的数据赋值给我们定义在data中的comment对象赋值
        this.setData({
          comment: JSON.parse(res.result)
          //拿到comment对象后我们就可以通过它显示数据在我们页面上了
        })
      }).catch(err => {
        console.log(err)
      })

      //想看
    var wantedId = options.movieid; //要先在对应的数据文本中对每个栏目定义wantedId、比如wantedId: 0 wantedId:1
    this.data.currentWantedId = wantedId; //借助顶部data作为中转，拿到上面这行wantedId后，将它放到下面var postWanted = postsWanted[]中

    //用户收藏功能
    var postsWanted = wx.getStorageSync('posts_wanted') //从缓存中读取所有的缓存状态
    if (postsWanted) { //postsWanted为真的情况，在缓存中存在
      var postWanted = postsWanted[wantedId] //读取其中一个缓存状态
      this.setData({
        isWanted: postWanted //将是否被收藏的状态上绑定到isWanted这个变量上
      })
    } else { //为假的情况，缓存中为空的情况
      var postsWanted = {}; //对postsWanted进行一个赋值操作，从而防止为空，从而省掉后面对它是否为空进行测试的步骤
      postsWanted[wantedId] = false; // 让当前的这篇文章状态为false，从而收藏星星不点亮
      wx.setStorageSync('posts_wanted', postsWanted); //将postsWanted对象放到缓存中
    }

    //看过
    var watchedId = options.movieid; //要先在对应的数据文本中对每个栏目定义watchedId、比如wantedId: 0 wantedId:1
    this.data.currentWatchedId = watchedId; //借助顶部data作为中转，拿到上面这行watchedId后，将它放到下面var postWatched = postsWatched[]中

    //用户收藏功能
    var postsWatched = wx.getStorageSync('posts_watched') //从缓存中读取所有的缓存状态
    if (postsWatched) { //postsWatched为真的情况，在缓存中存在
      var postWatched = postsWatched[watchedId] //读取其中一个缓存状态
      this.setData({
        isWatched: postWatched //将是否被收藏的状态上绑定到isWatched这个变量上
      })
    } else { //为假的情况，缓存中为空的情况
      var postsWatched = {}; //对postsWatched进行一个赋值操作，从而防止为空，从而省掉后面对它是否为空进行测试的步骤
      postsWatched[watchedId] = false; // 让当前的这篇文章状态为false，从而收藏星星不点亮
      wx.setStorageSync('posts_watched', postsWatched); //将postsWatched对象放到缓存中
    }
  },

  gotoWanted: function (event) {　　　　 // 定义gotoWanted事件用来确定文章是否收藏，如果没收藏就能点亮星星进行收藏
    var postsWanted = wx.getStorageSync('posts_wanted'); //获取缓存的方法
    var postWanted = postsWanted[this.data.currentWantedId]; //确定当前文章是否有缓存的状态，传递参数方法、借助其他参数来传递变量，如上的data
    postWanted = !postWanted; // 取反操作，收藏变成未收藏、未收藏变为收藏
    postsWanted[this.data.currentWantedId] = postWanted; //整体缓存的某一篇文章的缓存值等于postWanted从而更新一个变量
    wx.setStorageSync('posts_wanted', postsWanted); //更新文章是否收藏的缓存值,相当于在数据库中做了一次更新。
    //更新Data的数据绑定变量,从而实现图片切换
    this.setData({
      isWanted: postWanted //当前的isWanted为postWanted
    })
    
    if (postsWanted[this.data.currentWantedId] == true){
      db.collection('wanted').add({
        data: {
          movie: this.data.detail
        }
      }).then(res => {
        console.log('添加成功');
        this.setData({
          _wantedId:res._id
        })
      }).catch(err => {
        console.log('添加失败');
      })
    }else{
      db.collection('wanted').doc(this.data._wantedId).remove({
      }).then(res => {
        console.log('删除成功');
      }).catch(err => {
        console.log('删除失败');
      })
    }
  },

  gotoWatched: function (event) {　　　　 // 定义gotoWatched事件用来确定文章是否收藏，如果没收藏就能点亮星星进行收藏
    var postsWatched = wx.getStorageSync('posts_watched'); //获取缓存的方法
    var postWatched = postsWatched[this.data.currentWatchedId]; //确定当前文章是否有缓存的状态，传递参数方法、借助其他参数来传递变量，如上的data
    postWatched = !postWatched; // 取反操作，收藏变成未收藏、未收藏变为收藏
    postsWatched[this.data.currentWatchedId] = postWatched; //整体缓存的某一篇文章的缓存值等于postWatched从而更新一个变量
    wx.setStorageSync('posts_watched', postsWatched); //更新文章是否收藏的缓存值,相当于在数据库中做了一次更新。
    //更新Data的数据绑定变量,从而实现图片切换
    this.setData({
      isWatched: postWatched //当前的isWatched为postWatched
    })

    if (postsWatched[this.data.currentWatchedId] == true) {
      db.collection('watched').add({
        data: {
          movie: this.data.detail
        }
      }).then(res => {
        console.log('添加成功');
        this.setData({
          _watchedId: res._id
        })
      }).catch(err => {
        console.log('添加失败');
      })
    } else {
      db.collection('watched').doc(this.data._watchedId).remove({
      }).then(res => {
        console.log('删除成功');
      }).catch(err => {
        console.log('删除失败');
      })
    }
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})