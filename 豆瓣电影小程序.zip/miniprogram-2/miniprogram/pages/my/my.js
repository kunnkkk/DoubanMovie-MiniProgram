// miniprogram/pages/my/my.js
const db = wx.cloud.database()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    wantedLength: '',//想看几部
    watchedLength: '',//看过几部
    animationData: {},//逐渐消失动画
    hiddenBtn: false,//按钮消失
    showTrue: false,//信息是否显示
    message:{}
  },

  gotoWantedMoive: function() {
    wx.navigateTo({ //该方法跳转到其他页面，保留本身页面
      url: `../wantedMovie/wantedMovie`,
    })
  },

  gotoWatchedMoive: function() {
    wx.navigateTo({ //该方法跳转到其他页面，保留本身页面
      url: `../watchedMovie/watchedMovie`,
    })
  },

  onGotUserInfo: function(event) {
    console.log(event)
    this.setData({
      message:event.detail.userInfo
    })
    var animation = wx.createAnimation({
      duration: 100,
      timingFunction: 'linear',
    })
    this.animation = animation
    animation.opacity(0).step()
    this.setData({
      animationData: animation.export()
    })
    setTimeout(function() {
      this.setData({
        hiddenBtn: true
      })
    }.bind(this), 100)
    //显示信息
    var that = this;
    if (that.data.showTrue == true) {
      that.setData({
        showTrue: false,
      })
    } else {
      that.setData({
        showTrue: true,
      })
    }
  },


  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    //想看
    db.collection('wanted').where({
      _openid: 'orJsE5p5FhcVaSjNWN7OB08D8S0g'
    }).get().then(sucess => {
      console.log(sucess);
      this.setData({
        wantedLength: sucess.data.length
      })
    }).catch(err => {
      console.log(err)
    })
    //看过
    db.collection('watched').where({
      _openid: 'orJsE5p5FhcVaSjNWN7OB08D8S0g'
    }).get().then(sucess => {
      console.log(sucess);
      this.setData({
        watchedLength: sucess.data.length
      })
    }).catch(err => {
      console.log(err)
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {

  }
})